#include <stdio.h>

int main() {
    int mes = 12;
    float Celsius[12];

    printf("Digite as temperaturas:\n");
    for (int i = 0; i < mes; i++) {
        scanf("%f", &Celsius[i]);
    }

    float maiortemperatura = Celsius[0];
    for (int i = 1; i < mes; i++) {
        if (Celsius[i] > maiortemperatura) {
            maiortemperatura = Celsius[i];
        }
    }

    float menortemperatura = Celsius[0];
    for (int i = 1; i < mes; i++) {
        if (Celsius[i] < menortemperatura) {
            menortemperatura = Celsius[i];
        }
    }

    char *nomesMeses[] = {
        "Janeiro", "Fevereiro", "Marco", "Abril", "Maio", "Junho",
        "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
    };

    for (int i = 0; i < mes; i++) {
        if (i >= 0 && i < 12) {
            printf("%s: %.2f\n", nomesMeses[i], Celsius[i]);
        } else {
            printf("Erro: Mês inválido.\n");
        }
    }

    printf("Maior temperatura: %.2f\n", maiortemperatura);
    printf("Menor temperatura: %.2f\n", menortemperatura);

    return 0;
}