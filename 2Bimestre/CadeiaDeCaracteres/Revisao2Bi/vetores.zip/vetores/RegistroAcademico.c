#include <stdio.h>

int main() {
    int RA[7];
    float media[7];
    int alunoMaiorMedia = 0;

    printf("Digite o RA e a média final de cada aluno:\n");
    for (int i = 0; i < 7; i++) {
        scanf("%d %f", &RA[i], &media[i]);
        if (media[i] > media[alunoMaiorMedia]) {
            alunoMaiorMedia = i;
        }
    }

    printf("Aluno com maior média:\n");
    printf("RA: %d\n", RA[alunoMaiorMedia]);
    printf("Média: %.2f\n", media[alunoMaiorMedia]);

    printf("Alunos que precisam de exame:\n");
    for (int i = 0; i < 7; i++) {
        if (media[i] < 7) {
            float notaExame = 10 - media[i];
            printf("RA: %d, Nota necessária no exame: %.2f\n", RA[i], notaExame);
        }
    }

    return 0;
}
