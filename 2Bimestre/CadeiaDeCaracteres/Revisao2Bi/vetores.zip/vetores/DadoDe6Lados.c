#include <stdlib.h>

int main(){
    srand(time(NULL));
    int N,Jogadas;
    int Frequencia[6] = {0};

        printf("quantas vezes o dado sera lancado?\n");
        scanf("%d",&Jogadas);

        printf("Os numeros rolados foram:");
            for(int i=0; i<Jogadas; i++){
                N = rand() % 6 + 1;
                Frequencia[N-1]++;
                printf(" |%d |",N);
            }
        printf("\nFrequencia de Numeros\n");
            for(int i = 0; i<6; i++){
                printf("Numero %d: %d vezes\n",i + 1,Frequencia[i]);
            }
    return 0;
}