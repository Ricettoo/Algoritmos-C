#include <stdio.h>

int main() {
    float salarioFixo = 545.00;
    float taxaComissao = 0.05;

    float precos[10];
    int quantidades[10];
    float totalVendas = 0;
    float comissao;

    printf("Informe os preços dos objetos:\n");
    for (int i = 0; i < 10; i++) {
        scanf("%f", &precos[i]);
    }

    printf("Informe as quantidades vendidas de cada objeto:\n");
    for (int i = 0; i < 10; i++) {
        scanf("%d", &quantidades[i]);
        totalVendas += precos[i] * quantidades[i];
    }

    comissao = totalVendas * taxaComissao;
    float maiorVenda = 0;
    int posicaoMaiorVenda = 0;

    printf("Relatório de vendas:\n");
    for (int i = 0; i < 10; i++) {
        float valorTotalObjeto = precos[i] * quantidades[i];
        printf("Objeto %d: Quantidade vendida: %d, Valor unitário: %.2f, Valor total: %.2f\n",
               i + 1, quantidades[i], precos[i], valorTotalObjeto);

        if (valorTotalObjeto > maiorVenda) {
            maiorVenda = valorTotalObjeto;
            posicaoMaiorVenda = i;
        }
    }

    printf("Valor geral das vendas: %.2f\n", totalVendas);
    printf("Comissão do vendedor: %.2f\n", comissao);

    printf("Objeto mais vendido:\n");
    printf("Posição no vetor: %d\n", posicaoMaiorVenda + 1);
    printf("Valor total da venda: %.2f\n", maiorVenda);

    return 0;
}
