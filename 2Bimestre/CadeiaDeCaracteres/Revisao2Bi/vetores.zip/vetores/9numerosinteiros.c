#include <stdio.h>

int main() {
    int Entrada[9];

    for(int i = 0; i < 9; i++) {
        scanf("%d", &Entrada[i]);
        }
    
    for(int i = 0; i<9; i++){
        if(Entrada[i] % 2 == 0) {
            printf("%d eh par e o indice eh %d\n", Entrada[i], i);
            Entrada[i+1];
        }
    }
    return 0;
}