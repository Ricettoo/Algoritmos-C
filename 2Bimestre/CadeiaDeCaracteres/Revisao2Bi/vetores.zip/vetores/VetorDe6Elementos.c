#include <stdio.h>

int main() {
    int vetor[6];
    int quantidadePares = 0;
    int quantidadeImpares = 0;

    printf("Digite seis números inteiros:\n");
    for (int i = 0; i < 6; i++) {
        scanf("%d", &vetor[i]);
        if (vetor[i] % 2 == 0) {
            quantidadePares++;
        } else {
            quantidadeImpares++;
        }
    }

    printf("Números pares: ");
    for (int i = 0; i < 6; i++) {
        if (vetor[i] % 2 == 0) {
            printf("%d ", vetor[i]);
        }
    }
    printf("\nQuantidade de números pares: %d\n", quantidadePares);

    printf("Números ímpares: ");
    for (int i = 0; i < 6; i++) {
        if (vetor[i] % 2 != 0) {
            printf("%d ", vetor[i]);
        }
    }
    printf("\nQuantidade de números ímpares: %d\n", quantidadeImpares);

    return 0;
}
